# 📢 Marketing Materials & URL Usage Guide

## Ready-to-Use Marketing Templates

### Business Card Design

**Front:**
```
━━━━━━━━━━━━━━━━━━━━━
    🥟 AYMI SNACKS
   Fresh & Authentic
━━━━━━━━━━━━━━━━━━━━━

Samosa • Rolls • Murhi
Traditional Taste Since Years

aymisnacks.com
━━━━━━━━━━━━━━━━━━━━━
```

**Back:**
```
━━━━━━━━━━━━━━━━━━━━━
📞 +92 324 2441758
📧 shaheenayman786@gmail.com
💬 WhatsApp Orders Available

📍 Keamari, Karachi
🌐 aymisnacks.com

🌙 Ramadan Specials Available
━━━━━━━━━━━━━━━━━━━━━
```

### Flyer Template

```
╔═══════════════════════════════╗
║                               ║
║      🥟 AYMI SNACKS 🥟        ║
║                               ║
║   Fresh • Delicious • Daily   ║
║                               ║
╚═══════════════════════════════╝

🔥 SPECIAL OFFERS 🔥

Samosa ........................ Rs. 150
Chicken Roll .................. Rs. 200  
Special Murhi ................. Rs. 100

🌙 RAMADAN SPECIAL 🌙
Kachay Roll Samosa ............ Rs. 240

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📱 ORDER NOW
   WhatsApp: +92 324 2441758
   
🌐 FULL MENU
   aymisnacks.com/products

📍 LOCATION
   Keamari, Karachi
   
⏰ OPEN DAILY
   Mon-Sat: 10 AM - 10 PM
   Sunday: 11 AM - 9 PM

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[QR CODE]  aymisnacks.com
Scan to order online!
```

### WhatsApp Business Profile

**Business Name:** Aymi Snacks

**About:**
```
🥟 Fresh Traditional Snacks
📍 Keamari, Karachi
🌙 Ramadan Specials Available
💬 Order on WhatsApp
🌐 aymisnacks.com
```

**Website:** `aymisnacks.com`

**Address:** Keamari, Karachi, Pakistan

**Business Hours:**
```
Monday - Saturday: 10:00 AM - 10:00 PM
Sunday: 11:00 AM - 9:00 PM
Ramadan: All Day Service
```

**Catalog:** Link to `aymisnacks.com/products`

### Facebook Page Setup

**Name:** Aymi Snacks

**Category:** Fast Food Restaurant / Snack Bar

**About:**
```
Fresh, authentic snacks made with love 🥟

Traditional samosas, rolls, and murhi served fresh daily in Keamari, Karachi.

Family-owned business bringing you the taste of home-cooked meals.

🌙 Special Ramadan menu available
💬 Order on WhatsApp: +92 324 2441758
```

**Website:** `aymisnacks.com`

**Call to Action:** "Order Food" → `https://wa.me/923242441758`

**Menu Link:** `aymisnacks.com/products`

**Location:** Keamari, Karachi

### Instagram Bio

**Option 1:**
```
🥟 Fresh Traditional Snacks
📍 Keamari, Karachi
🌙 Ramadan Specials Available
👇 Order Online
aymisnacks.com
```

**Option 2:**
```
Home-style snacks • Made fresh daily
📞 +92 324 2441758
🌐 aymisnacks.com
📍 Keamari • Delivering fresh happiness 🥟
```

**Bio Link:** `aymisnacks.com`

### Instagram Story Templates

**Story 1 - Menu:**
```
[Product Photo]

Fresh Samosas! 🥟
Only Rs. 150

Swipe Up to Order
👆 aymisnacks.com/products
```

**Story 2 - Ramadan:**
```
[Ramadan Banner]

🌙 RAMADAN MUBARAK 🌙

Special Iftar Menu
Available Now

Order: aymisnacks.com/ramadan
```

**Story 3 - Contact:**
```
[Business Hours Graphic]

⏰ We're Open!

Order Now:
📱 +92 324 2441758
🌐 aymisnacks.com
```

### Google My Business

**Business Name:** Aymi Snacks

**Category:** Snack Bar

**Description:**
```
Fresh traditional snacks in Keamari, Karachi. Specializing in authentic samosas, rolls, and murhi made with quality ingredients. Family business serving the community with home-style cooking. Special Ramadan menu available. Order online or call for delivery.
```

**Website:** `aymisnacks.com`

**Menu URL:** `aymisnacks.com/products`

**Phone:** +92 324 2441758

**Address:** Keamari, Karachi, Sindh, Pakistan

**Attributes:**
- Delivery
- Takeout
- Family-owned
- Halal food

**Photos:** Upload product images, storefront, team

### Packaging Stickers

**Option 1 - Round Sticker:**
```
┌─────────────────┐
│   🥟 AYMI      │
│    SNACKS      │
│                 │
│ aymisnacks.com  │
│ +92 324 2441758 │
└─────────────────┘
```

**Option 2 - Square Sticker:**
```
┌─────────────────────────┐
│  Thank you for ordering!│
│                         │
│   Order again:          │
│   aymisnacks.com        │
│                         │
│   Follow us on:         │
│   📱 Instagram          │
│   📘 Facebook           │
└─────────────────────────┘
```

### Menu Card (To Include with Orders)

```
╔══════════════════════════════════╗
║      🥟 AYMI SNACKS MENU 🥟     ║
╚══════════════════════════════════╝

FRESH SNACKS
├─ Samosa ................... Rs. 150
├─ Chicken Roll ............. Rs. 200
├─ Beef Roll ................ Rs. 220
├─ Special Murhi ............ Rs. 100
└─ Cheese Roll .............. Rs. 180

🌙 RAMADAN SPECIAL
├─ Kachay Roll Samosa ....... Rs. 240
└─ Spring Rolls (Frozen) .... Rs. 220

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📱 ORDER ONLINE
   aymisnacks.com

💬 WhatsApp
   +92 324 2441758

📧 Email
   shaheenayman786@gmail.com

📍 Location
   Keamari, Karachi

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⭐ Rate us online!
   aymisnacks.com/contact

   Share your experience and help
   us serve you better!
```

### Email Signature

```html
--
🥟 Aymi Snacks
Fresh & Authentic Traditional Snacks

📞 +92 324 2441758
📧 shaheenayman786@gmail.com
🌐 aymisnacks.com
📍 Keamari, Karachi

🌙 Ramadan Specials Available | Order Online
```

### SMS Marketing Template

**Welcome Message:**
```
Welcome to Aymi Snacks! 🥟

Fresh samosas, rolls & more delivered to your door.

Order now: +92 324 2441758
Menu: aymisnacks.com/products

Reply STOP to unsubscribe
```

**Ramadan Promotion:**
```
🌙 Ramadan Mubarak! 🌙

Pre-order Kachay Samosa & Spring Rolls for Iftar.

Special packages available.

Order: aymisnacks.com/ramadan
Call: +92 324 2441758

-Aymi Snacks
```

**Weekly Special:**
```
Fresh samosas ready! 🥟
Rs. 150 only

Order now for delivery:
📱 +92 324 2441758
🌐 aymisnacks.com

-Aymi Snacks, Keamari
```

### Vehicle Branding

**Side Panel:**
```
════════════════════════════════

       🥟 AYMI SNACKS
    Fresh Traditional Snacks

     aymisnacks.com
   📞 +92 324 2441758

════════════════════════════════
```

**Rear Window:**
```
Order Online!
aymisnacks.com
+92 324 2441758
```

### Receipt/Invoice Footer

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Thank you for choosing Aymi Snacks!

Rate your experience:
aymisnacks.com/contact

Order again:
📱 +92 324 2441758
💬 WhatsApp Available
🌐 aymisnacks.com

Follow us for daily specials!
📘 Facebook: Aymi Snacks
📱 Instagram: @aymisnacks

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Banner/Poster

```
╔══════════════════════════════════════╗
║                                      ║
║         🥟 AYMI SNACKS 🥟           ║
║                                      ║
║      FRESH • AUTHENTIC • DAILY       ║
║                                      ║
╚══════════════════════════════════════╝

        [PRODUCT PHOTOS]

    ━━━━━━━━━━━━━━━━━━━━━━━━━━

         OUR SPECIALTIES

    🥟 Fresh Samosa ......... Rs. 150
    🌯 Chicken Roll ......... Rs. 200
    🥜 Special Murhi ........ Rs. 100

    ━━━━━━━━━━━━━━━━━━━━━━━━━━

       🌙 RAMADAN SPECIAL 🌙
    Kachay Roll Samosa ... Rs. 240

    ━━━━━━━━━━━━━━━━━━━━━━━━━━

         ORDER NOW!

    📱 +92 324 2441758
    🌐 aymisnacks.com
    📍 Keamari, Karachi

         [QR CODE]
    Scan to order online!
```

### Table Tent Card

```
╔═══════════════════════╗
║   🥟 AYMI SNACKS     ║
╚═══════════════════════╝

Order from your table!

Scan QR Code →  [QR]

Or visit:
aymisnacks.com/products

WhatsApp:
+92 324 2441758
```

### Promotional Offer Template

```
🎉 SPECIAL OFFER 🎉

Buy 10 Samosas
Get 2 FREE! 🥟

Limited Time Only

Order Now:
📱 +92 324 2441758
🌐 aymisnacks.com

Terms apply. Valid till [DATE]

-Aymi Snacks
Keamari, Karachi
```

## QR Code Generator Instructions

### Where to Create QR Codes:

1. **qr-code-generator.com** (Recommended)
   - Free, easy to use
   - Customizable colors
   - Download high resolution

2. **QRCode Monkey** (qr-code-monkey.com)
   - Free forever
   - Custom logo in center
   - No watermark

### QR Codes to Create:

**Main Website:**
```
URL: aymisnacks.com
Use for: Business cards, flyers, posters
```

**Products Page:**
```
URL: aymisnacks.com/products
Use for: Menus, table tents, packaging
```

**WhatsApp Direct:**
```
URL: https://wa.me/923242441758?text=Hi!%20I%20want%20to%20order
Use for: Quick ordering, promotional materials
```

**Ramadan Special:**
```
URL: aymisnacks.com/ramadan
Use for: Ramadan-specific materials
```

### QR Code Design Tips:

- Use brand colors (orange, gold, red)
- Add small logo in center
- Include text: "Scan to Order"
- Print size: At least 2x2 cm (readable)
- Test before printing!

## Social Media Post Templates

### Facebook Post 1:
```
🥟 Fresh Samosas Ready! 🥟

Crispy golden perfection, made fresh this morning.

Order now for delivery:
📱 +92 324 2441758

Or order online:
👉 aymisnacks.com/products

#AymiSnacks #Karachi #FreshFood #Samosa #KeamariFood
```

### Facebook Post 2:
```
🌙 Ramadan Mubarak! 🌙

Pre-order your iftar items now!

🥟 Kachay Samosa
🌯 Spring Rolls
📦 Family Combo Packs

Special packages available.

Order: aymisnacks.com/ramadan
Call: +92 324 2441758

#Ramadan #Iftar #Karachi #AymiSnacks
```

### Instagram Caption:
```
Fresh, crispy, delicious! 🥟✨

Made with love, served with pride.

Order now 👇
📱 +92 324 2441758
🌐 aymisnacks.com

#AymiSnacks #KarachiFood #FreshSnacks #Samosa #FoodieKarachi #KeamariEats #PakistaniFood #FoodDelivery
```

## Summary

All your marketing materials now feature your clean URLs:

✅ **Primary:** `aymisnacks.com`
✅ **Menu:** `aymisnacks.com/products`  
✅ **Ramadan:** `aymisnacks.com/ramadan`
✅ **Contact:** `aymisnacks.com/contact`

Simple, professional, memorable! 🎉

---

**Questions?** shaheenayman786@gmail.com
